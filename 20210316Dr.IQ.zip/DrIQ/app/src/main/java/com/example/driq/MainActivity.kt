package com.example.driq
/** 21년 3월 11일 최종 */
import android.Manifest
import android.app.Dialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.StrictMode
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.bumptech.glide.Glide


class MainActivity : AppCompatActivity() {
    private lateinit var said: EditText

    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var phone: EditText

    private lateinit var region: Spinner

    private lateinit var clear_text_button: Button
    private lateinit var send_button: Button

    private lateinit var said_error_textview: TextView
    private lateinit var region_error_textview: TextView
    private lateinit var type_error_textview: TextView

    private lateinit var dialog: Dialog

    private lateinit var sf: SharedPreferences

    var said_input_text: String = ""
    var region_input_text: String = ""
    var email_txt: String = ""
    var phone_txt: String = ""
    var pw_txt: String = ""
    var type_input_text: String = ""

    var said_input_text_length: Int = 0
    var region_input_text_length: Int = 0
    val PERMISSIONS_REQUEST_READ_SMS = 100
    var type_state: Int = 0
    private val INVITE_COMPLETED = 1
    var items = arrayOf(
            "- 선택 -", "  경기광주국사  ", "  모란국사  ", "  분당국사  ", "  성남국사  ", "  수내국사  ", "  여주국사  ", "  이천국사  ", "  장호원국사  ", "  하남국사  "
    )

    /** 다른 부분을 클릭하면 키보드가 내려가는 함수  */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val focusView = currentFocus
        if (focusView != null) {
            val rect = Rect()
            focusView.getGlobalVisibleRect(rect)
            val x = ev.x.toInt()
            val y = ev.y.toInt()
            if (!rect.contains(x, y)) {
                val imm =
                        getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm?.hideSoftInputFromWindow(focusView.windowToken, 0)
                focusView.clearFocus()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        overridePendingTransition(0, 0)
        /** 변수 선언 */
        val radioGroup = findViewById<RadioGroup>(R.id.radiogroup1)

        said = findViewById<EditText>(R.id.said)
        clear_text_button = findViewById<Button>(R.id.clear_text_button)
        send_button = findViewById<Button>(R.id.send_button)
        said_error_textview = findViewById<TextView>(R.id.said_error_textView)
        region = findViewById<Spinner>(R.id.region)
        region_error_textview = findViewById<TextView>(R.id.region_error_textview)
        type_error_textview = findViewById<TextView>(R.id.type_error_textview)


        /** 로그인 dialog xml 연동 */
        dialog = Dialog(this@MainActivity) // Dialog 초기화
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE) // 타이틀 제거
        dialog.setContentView(R.layout.inputdialog)

        email = dialog.findViewById(R.id.email) as EditText
        password = dialog.findViewById(R.id.password) as EditText
        phone = dialog.findViewById(R.id.phone) as EditText

        /** app 내 저장된 데이터 연동 */
        sf = getSharedPreferences("sFile", Context.MODE_MULTI_PROCESS)
        email_txt = sf.getString("email", "").toString()
        pw_txt = sf.getString("password", "").toString()
        phone_txt = sf.getString("phone", "").toString()

        /** 다크모드 해제 */
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        /** mail 사용을 위한 Thread 생성 */
        if (android.os.Build.VERSION.SDK_INT > 9) {
            val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
            StrictMode.setThreadPolicy(policy)
        }

        /** gif 파일 동작  */
        val imageView = findViewById<ImageView>(R.id.imageView)
        Glide.with(this).load(R.raw.gif).into(imageView)

        /** SAID 입력 */
        said.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                said_error_textview.visibility = View.GONE // 아래 SAID 에러 메시지 제거
                said.setBackgroundResource(R.drawable.white_edittext) // SAID 입력 창 테두리 흰색으로 변경
                clear_text_button.visibility = View.GONE // 입력 Clear 버튼 제거
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                said_input_text = said.text.toString() // SAID 입력 창의 값 String 으로 읽어오기
                said_input_text_length = said_input_text.length // 입력된 값의 length 저장
                clear_text_button.visibility = View.VISIBLE // 입력 Clear 버튼 보이도록 표시
                // SAID가 11자리인 경우
                if (said_input_text_length == 11) {
                    said_error_textview.visibility = View.GONE // 아래 SAID 에러 메시지 제거
                    said.setBackgroundResource(R.drawable.white_edittext) // SAID 입력 창 테두리 흰색으로 변경
                    // 서비스 유형과 국사가 모두 선택되어 있는 경우
                    if (type_state == 1 && region_input_text_length > 6) {
                        send_button.isEnabled = true // 요청 전송 버튼 enable
                        send_button.setClickable(true) // 요청 전송 버튼 clickable
                        send_button.setBackgroundColor(Color.parseColor("#00dac5")) // 요청 전송 버튼 민트색 넣어주기
                    }
                } else {
                    said_error_textview.visibility = View.VISIBLE // 아래 SAID 아래 메시지 표시
                    said.setBackgroundResource(R.drawable.red_edittext) // SAID 입력 창 테두리 빨간색으로 변경
                    send_button.setClickable(false) // 전송 버튼 비활성화
                    send_button.setBackgroundColor(Color.parseColor("#efefef")) // 요청 전송 버튼 회색 넣어주기
                    if (said_input_text_length == 0) {
                        clear_text_button.visibility = View.GONE // Clear 버튼 안보이도록
                    }

                }

            }

        })

        /** 스피너 사용 시 필요한 adapter와 함수 */
        region.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        region.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                region_input_text = items[position] // 선택된 국사 값을 변수에 저장
                region_input_text_length = region_input_text.length // 선택된 값의 String 길이 저장
                region_error_textview.visibility = View.GONE // 선택된 경우 아래 에러메시지 제거
                // 국사가 선택되면
                if (region_input_text_length > 6) {
                    // 서비스 유형과 국사가 모두 선택되어 있는 경우
                    if (said_input_text_length == 11 && type_state == 1) {
                        send_button.isEnabled = true // 요청 전송 버튼 enable
                        send_button.setClickable(true) // 요청 전송 버튼 clickable
                        send_button.setBackgroundColor(Color.parseColor("#00dac5")) // 요청 전송 버튼 민트색 넣어주기
                    }
                    else{
                        region_error_textview.visibility = View.GONE
                    }
                } else {
                    region_error_textview.visibility = View.VISIBLE // 선택되지 않은 경우 아래 에러메시지 표시
                    send_button.setClickable(false) // 전송 버튼 비활성화
                    send_button.setBackgroundColor(Color.parseColor("#efefef")) // 요청 전송 버튼 회색 넣어주기
                }

            }
        }

        /** radiogroup 선택 함수  */
        radioGroup?.setOnCheckedChangeListener { group, checkedId ->
            type_error_textview.visibility = View.GONE
            println(checkedId)
            //서비스유형 중 tv가 선택된 경우
            if (checkedId == R.id.tv) {
                type_input_text = "TV"
                type_state = 1 // type_state 1로 셋팅
                type_error_textview.visibility = View.GONE // 아래 에러메시지 제거
                // 서비스 유형과 국사가 모두 선택되어 있는 경우
                if (said_input_text_length == 11 && region_input_text_length > 6) {
                    // send 버튼 활성화
                    send_button.isEnabled = true // 요청 전송 버튼 enable
//                    send_button.isClickable = true // 요청 전송 버튼 clickable
                    send_button.setClickable(true)
                    send_button.setBackgroundColor(Color.parseColor("#00dac5")) // 요청 전송 버튼 민트색 넣어주기
                }
                //internet이 선택된 경우
            } else if (checkedId == R.id.internet) {
                type_input_text = "인터넷"
                type_error_textview.visibility = View.GONE // 아래 에러메시지 제거
                type_state = 1 // type_state 1로 셋팅
                if (said_input_text_length == 11 && region_input_text_length > 6) {
                    // send 버튼 활성화
                    send_button.isEnabled = true // 요청 전송 버튼 enable
                    send_button.setClickable(true) // 요청 전송 버튼 clickable
                    send_button.setBackgroundColor(Color.parseColor("#00dac5")) // 요청 전송 버튼 민트색 넣어주기
                }
            } else {
                region_error_textview.visibility = View.VISIBLE // 선택되지 않은 경우 아래 에러메시지 표시
                type_state = 0
                send_button.setClickable(false) // 전송 버튼 비활성화
                send_button.setBackgroundColor(Color.parseColor("#efefef")) // 요청 전송 버튼 회색 넣어주기
            }
        }

        /** send 버튼 이벤트 생성 */
        send_button.setOnClickListener(View.OnClickListener {
            try {
                callPermission()

//                sendMMSG()
//                SmsManager.getDefault().sendTextMessage("01073332963", null, "되나", null,null);
//                val sender = GMailSender(email_txt, pw_txt)
//                sender.sendMail("[요청]",
//                        """
//                            SAID:$said_input_text
//                            TV/인터넷:$type_input_text
//                            국사:${region_input_text.replace("  ".toRegex(), "")}
//                            휴대폰번호:$phone_txt
//                            """.trimIndent(),
//                        "junha.nam@kt.com")
//                sender.sendMail("[요청]",
//                        """
//                            SAID:$said_input_text
//                            TV/인터넷:$type_input_text
//                            국사:${region_input_text.replace("  ".toRegex(), "")}
//                            휴대폰번호:$phone_txt
//                            """.trimIndent(),
//                        "seunghoon.bae@kt.com")
//                Toast.makeText(applicationContext, "메일 전송이 완료되었습니다.", Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
//                Toast.makeText(applicationContext, "메일 전송 실패", Toast.LENGTH_SHORT).show()
//                Log.e("SendMail", e.message, e)
            }
//            Toast.makeText(applicationContext, "버튼 클릭클리익", Toast.LENGTH_SHORT).show()
            // 초기상태로 만들어주기
            said.setText("")
            val rg = findViewById<View>(R.id.radiogroup1) as RadioGroup
            val rb = findViewById<View>(rg.getCheckedRadioButtonId()) as RadioButton
            rb.setChecked(false)
            type_error_textview.setVisibility(View.VISIBLE)
            region.setSelection(0)



        })
        password.transformationMethod = CustomPasswordTransformationMethod()
    }
    private fun callPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.READ_SMS),PERMISSIONS_REQUEST_READ_SMS
            )
            sendMMSG()
        } else {
            sendMMSG()
        }
    }
    /** clear button 클릭시  */
    fun btnStart(v: View?) {
        said.setText("")
    }

    /** 상단바 생성  */
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.list_menu, menu)
        return true
    }

    /** 상단바의 오른쪽 버튼 클릭 시 dialog 팝업  */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.newPostbt) {
            showDialog()
            return true
        }
        else if(id == R.id.newPostbt2){
            val intent = Intent(this, Print_MMS_Activity::class.java)
            startActivity(intent)
            overridePendingTransition(0, 0)
            return true
        }
        return super.onOptionsItemSelected(item)
    }


    /** dialog의 confirm 버튼 클릭 시 앱 내 데이터 저장  */
    fun showDialog() {
        dialog.show()
        val confirm: Button = dialog.findViewById(R.id.confirm)
        confirm.setOnClickListener { //                SharedPreferences sharedPreferences = getSharedPreferences("sFile",MODE_PRIVATE);
            val editor: SharedPreferences.Editor = sf.edit()
            email_txt = email.getText().toString()
            pw_txt = password.getText().toString()
            phone_txt = phone.getText().toString()

            editor.putString("email", email_txt)
            editor.commit()
            editor.putString("password", pw_txt)
            editor.commit()
            editor.putString("phone", phone_txt)
            editor.commit()
            dialog.dismiss()
            System.runFinalization()
            val i = baseContext.packageManager.getLaunchIntentForPackage(baseContext.packageName)
            i!!.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
    }

    private fun sendMMSG() {
        val mmsUri: Uri = Uri.parse("mmsto:")
        val sendIntent = Intent(Intent.ACTION_SEND, mmsUri)

        val sent: String = "SMS_SENT"
        val delivered : String  = "SMS_DELIVERED"

        val sentPI : PendingIntent = PendingIntent.getBroadcast(this, 0, Intent(sent), 0)


        sendIntent.addCategory("android.intent.category.DEFAULT")
        sendIntent.addCategory("android.intent.category.BROWSABLE")
        sendIntent.putExtra("address", "junha.nam@kt.com")

        sendIntent.putExtra("subject", "[요청]")
        sendIntent.putExtra(
            "sms_body", """
                            SAID:$said_input_text
                            TV/인터넷:$type_input_text
                            국사:${region_input_text.replace("  ".toRegex(), "")}
                            """.trimIndent()
        )
        startActivityForResult(sendIntent, 0)

//        sendIntent.putExtra("exit_on_sent", true);
//        super.onBackPressed();

//        finish()
//        System.out.println(sendIntent.extras.toString())

    }

}