package com.example.driq;


import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.MessageFormat;


public class Print_MMS_Activity extends AppCompatActivity {

    private TextView textview;
    private ScrollView scrollView;
    private Context context;
    private static final int PERMISSIONS_REQUEST_READ_SMS = 100;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.print_mms);

        /** 다크모드 해제 */
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        textview = (TextView) findViewById(R.id.textview);
        scrollView = (ScrollView) findViewById(R.id.scrollView);

        callPermission();

    }

    private void callPermission(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_SMS)!= PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.READ_SMS},
                    PERMISSIONS_REQUEST_READ_SMS);
            readMMS();
        }else{
//            System.out.println("들어왔나요?");
            readMMS();
        }
    }

    // android MMS 모니터링 http://devroid.com/80181708954

    private String getAddressNumber(int id) {
        String selectionAdd = new String("msg_id=" + id);
        String uriStr = MessageFormat.format("content://mms/{0}/addr", Integer.toString(id)); // id를 형변환해주지 않으면, 천단위 넘어가면 콤마가 붙으므로 오류가 나게 된다.
        Uri uriAddress = Uri.parse(uriStr);
        Cursor cAdd = getContentResolver().query(uriAddress, null, selectionAdd, null, null);
        System.out.println("cadd" + cAdd.toString());
        String name = null;
        if (cAdd.moveToFirst()) {
            do {
                String number = cAdd.getString(cAdd.getColumnIndex("address"));
                if (number != null ) {
                    try {
                        Long.parseLong(number.replace("-", ""));
                        name = number;
                    }
                    catch (NumberFormatException nfe) {
                        if (name == null) {
                            name = number;
                        }
                    }
                }
            } while (cAdd.moveToNext());
        }
        if (cAdd != null) {
            cAdd.close();
        }

        return name;

    }

    // android MMS 모니터링 http://devroid.com/80181708954

    private String getMmsText(String id) {
        Uri partURI = Uri.parse("content://mms/part/" + id);
        InputStream is = null;
        StringBuilder sb = new StringBuilder();
        try {
            is = getContentResolver().openInputStream(partURI);
            if (is != null) {
                InputStreamReader isr = new InputStreamReader(is, "UTF-8");
                BufferedReader reader = new BufferedReader(isr);
                String temp = reader.readLine();
                while (temp != null) {
                    sb.append(temp);
                    // if (sb.length() > 100) break;
                    temp = reader.readLine();
                }
            }
        } catch (IOException e) {}

        finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {}
            }
        }
        return sb.toString();
    }


    private String populateFromMmsPart(String msgId) {
        ContentResolver contentResolver = getContentResolver();
        Uri messages = Uri.parse("content://mms/part");
        Cursor c = contentResolver.query(messages, null, "mid=" + msgId, null, null);
        String msg = "";
        if (c.moveToFirst()) {
            String mid = c.getString(c.getColumnIndex("mid"));
            String type = c.getString(c.getColumnIndex("ct"));

            if (!"application/smil".equals(type)) {
                // Put all the addresses in one place
//                msg += "\naddress : " + getAddressNumber(Integer.parseInt(mid));
                if ("text/plain".equals(type)) {
                    // MMS is just plain text, so get the text
                    String data = c.getString(c.getColumnIndex("_data"));
                    String body;
                    if (data != null) {
                        body = getMmsText(msgId);
                    } else {
                        body = c.getString(c.getColumnIndex("text"));
                    }
                    // if (body.length() > 100) body = body.substring(0,100);
                    msg += "\n" + body;
                }
            }
        }
        c.close();
        return msg;
    }


    private void readMMS() {
        Cursor c = getContentResolver().query(Uri.parse("content://mms"), null, "sub" + " LIKE ?", new String[] {"%DRIQ%"}, null);
//        new String[]{"0317210141"}
        if (c.moveToFirst()) {
            do {
                String msg = "";
                System.out.println(c.getString(c.getColumnIndexOrThrow("sub")));
//                String msg = "\ntime : " + c.getString(c.getColumnIndexOrThrow("date"));
                String id =  c.getString(c.getColumnIndexOrThrow("_id"));
                msg += populateFromMmsPart(id);
                System.out.println(id);
//                System.out.println("모니터링");
                textview.append("\n========================================================="+msg);

            } while (c.moveToNext());
        }

        c.close();
        scrollView.scrollTo(0,0);
//        writeFile(textview.getText().toString(),mRoot+ File.separator+"rpt.txt");
    }

    private String mRoot = Environment.getExternalStorageDirectory().getAbsolutePath(); // SD카드 루트

    // BufferedOutputStream 파일쓰기
    static void writeFile(String fullTxt, String path) {

        BufferedOutputStream bos = null;
        try {
            bos = new BufferedOutputStream(new FileOutputStream(path));
            bos.write(fullTxt.getBytes());
            bos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** 상단바 생성 */
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.list_menu, menu);
        return true;
    }

}