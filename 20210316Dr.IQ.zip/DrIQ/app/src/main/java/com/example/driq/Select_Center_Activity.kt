package com.example.driq

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class Select_Center_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.center_select_main)
        /** 다크모드 해제 */
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        /**변수 선언 */
        var bt1 = findViewById<Button>(R.id.bt1)

        /** 강남 버튼 클릭시 강남관련 국사 스피너 페이지 이동 */
        bt1.setOnClickListener({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
//            overridePendingTransition(0, 0)
        })

    }
}